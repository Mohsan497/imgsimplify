import { NEW_POSTS, POST_EXPANSIONS } from "./postsExtra";

export type PostBlock =
  | { type: "p"; text: string }
  | { type: "h2"; text: string }
  | { type: "ul"; items: string[] }
  | { type: "ol"; items: string[] };

export interface Post {
  slug: string;
  title: string;
  /** Meta description, 140-160 characters. */
  description: string;
  /** ISO date, e.g. "2026-09-28". */
  date: string;
  category: string;
  /** ISO date of the last meaningful update. Used for dateModified in the article schema. */
  updated?: string;
  /** Slug of the ImgSimplify tool this article links to (see constants/tools.ts). */
  toolSlug: string;
  blocks: PostBlock[];
}

export const BLOG = {
  title: "The ImgSimplify Blog",
  metaTitle: "Image Optimization Guides: Compress, Convert & Resize",
  description:
    "Free guides on JPG vs PNG vs WebP, compressing images without losing quality, converting formats and more. Practical image tips from ImgSimplify.",
  intro:
    "Practical guides on image formats, compression and web performance, from the team behind ImgSimplify's free, private image tools.",
};

// Newest first. To add an article: add one object here, nothing else.
const BASE_POSTS: Post[] = [
  {
    slug: "image-seo-guide",
    title: "Image SEO: How to Optimize Images for Google Search",
    description:
      "Learn how to make your images easier for Google to find and faster for visitors to load, with file names, alt text, formats and page speed tips.",
    date: "2026-09-30",
    category: "SEO",
    toolSlug: "compress-image",
    blocks: [
      { type: "p", text: "Images can bring visitors to your site in two ways: through Google Images, and by making your pages faster and more useful in ordinary search. Most people upload pictures without a second thought, which is a missed opportunity. A few simple habits help search engines understand your images and keep your pages quick to load." },
      { type: "h2", text: "Start with a descriptive file name" },
      { type: "p", text: "A file called IMG_4821.jpg tells Google nothing. A file called red-running-shoes-side-view.jpg describes exactly what is in the picture. Use short, plain words that describe the image, separate them with hyphens, and keep everything lowercase. Rename the file before you upload it, because changing the name later can break existing links." },
      { type: "h2", text: "Write useful alt text" },
      { type: "p", text: "Alt text is a short description added to the image tag. It helps people who use screen readers, it appears if the image fails to load, and it gives search engines extra context. Describe what the image shows in a natural sentence, for example 'Person resizing a photo on a laptop'. Do not stuff it with keywords, and leave the alt text empty for purely decorative images so screen readers skip them." },
      { type: "h2", text: "Choose the right format" },
      { type: "p", text: "Google can index common formats including JPEG, PNG, WebP, AVIF, GIF and SVG. For photographs, WebP or JPG is usually best. For logos and graphics with sharp edges or transparency, PNG, WebP or SVG works well. Smaller modern formats help your pages load faster, which is good for visitors and part of the overall page experience." },
      { type: "h2", text: "Resize and compress every image" },
      { type: "p", text: "Speed is the biggest image factor for most sites. Resize each picture to the size it will actually appear, then compress it. A photo taken on a phone can be several megabytes, while the version your page needs is often under 200KB. Use the Resize Image tool first and the Compress Image tool second, and your pages will load much faster." },
      { type: "h2", text: "Use real image tags for important pictures" },
      { type: "p", text: "Google finds images most reliably when they are placed with a normal img element that points to the file. Images that only exist as CSS backgrounds are harder for search engines to associate with your content. If a picture matters for search, put it in the page as a regular image." },
      { type: "h2", text: "Put images near relevant text" },
      { type: "p", text: "Search engines use the words around an image to understand it. Place each picture close to the paragraph that explains it, and consider adding a short caption when it helps the reader. A photo of a product next to its description is far clearer than the same photo in an unrelated part of the page." },
      { type: "h2", text: "Make sure Google can crawl your images" },
      { type: "p", text: "Check that your robots.txt file does not block the folder your images live in, and that the pages containing them are indexed. You can see how your pages are doing in Google Search Console. An image sitemap is optional, but it can help on sites with many pictures that are loaded in unusual ways." },
      { type: "h2", text: "Do not forget speed on mobile" },
      { type: "p", text: "Most visitors arrive on phones, often on slower connections. Lazy load images that are below the first screen, set width and height so the layout does not jump around, and avoid loading a huge desktop image on a small screen. Faster pages keep readers on your site longer." },
      { type: "h2", text: "A quick image SEO checklist" },
      { type: "ol", items: [
        "Rename the file with a short, descriptive, hyphenated name.",
        "Resize the image to the size it will be displayed at.",
        "Compress it, aiming for a quality around 75% to 85% for photos.",
        "Consider WebP for smaller files, keeping JPG or PNG where compatibility matters.",
        "Add clear alt text that describes the image.",
        "Place it next to relevant text and use a normal image tag.",
      ] },
      { type: "p", text: "Preparing images this way takes only a minute per picture and adds up quickly across a whole site. ImgSimplify runs inside your browser, so you can resize, compress and convert your images without uploading them anywhere." },
    ],
  },
  {
    slug: "convert-png-to-jpg",
    title: "How to Convert PNG to JPG (and When You Should Not)",
    description:
      "Need a smaller file or a format every app accepts? Learn how to convert PNG to JPG, what happens to transparency, and which quality to choose.",
    date: "2026-09-25",
    category: "Converting",
    toolSlug: "png-to-jpg",
    blocks: [
      { type: "p", text: "PNG files are popular because they keep every pixel exactly as it was. The downside is that a PNG photo or screenshot can be surprisingly big, and some upload forms only accept JPG. Converting PNG to JPG is a quick fix, but it is not always the right move. This guide shows you how to do it and how to decide." },
      { type: "h2", text: "Why people convert PNG to JPG" },
      { type: "ul", items: [
        "The file is too large for an email, form or website upload.",
        "A service only accepts JPG or JPEG files.",
        "The image is a photograph, where JPG usually gives the best size for the quality.",
        "You want one common format for a batch of pictures.",
      ] },
      { type: "h2", text: "What changes when you convert" },
      { type: "p", text: "PNG is lossless, while JPG is lossy. When you save as JPG, the encoder discards fine detail that is hard to notice, which is exactly why the file gets smaller. At a sensible quality setting the difference is invisible for photographs, but it can show up around sharp edges and text." },
      { type: "h2", text: "What happens to transparent areas" },
      { type: "p", text: "PNG can have transparent backgrounds, but JPG cannot. When you convert, every transparent pixel has to become a solid colour. ImgSimplify fills transparent areas with white. That is fine for a product photo that will sit on a white page, but a logo with a transparent background will get a white box around it. If you need to keep transparency, convert to WebP or keep the PNG." },
      { type: "h2", text: "How to convert PNG to JPG online" },
      { type: "ol", items: [
        "Open the PNG to JPG tool.",
        "Drop in your PNG file or click to choose it.",
        "Adjust the quality slider. Around 85% to 90% keeps most images sharp, and lower values give smaller files.",
        "Compare the original and new file size shown next to the preview.",
        "Click Download to save your JPG.",
      ] },
      { type: "h2", text: "Which quality should you choose" },
      { type: "p", text: "For photographs, 80% to 90% is a good range. For images that contain text or thin lines, such as screenshots of a document, go higher because JPG can leave faint blocky marks around sharp edges. If the file is still too big after converting, reduce the pixel dimensions with the Resize Image tool rather than dropping the quality too low." },
      { type: "h2", text: "When you should keep the PNG instead" },
      { type: "ul", items: [
        "Logos, icons and graphics with flat colours and sharp edges.",
        "Screenshots that contain a lot of text.",
        "Anything with a transparent background that you need to keep.",
        "Images you plan to edit again, because a lossless file is a better master copy.",
      ] },
      { type: "h2", text: "A good workflow" },
      { type: "p", text: "Keep your original PNG as the master and create the JPG as a copy for sharing or uploading. Never convert a JPG back to PNG expecting the quality to return. Once detail is lost in a JPG, a new PNG will simply preserve the lower quality at a larger size." },
      { type: "h2", text: "Consider WebP as well" },
      { type: "p", text: "If your goal is a smaller file for a website, WebP is often an even better choice than JPG because it can shrink the file further and it keeps transparency. The PNG to WebP tool does this in the same way. Use JPG when you need the widest compatibility, and WebP when the destination supports it." },
      { type: "p", text: "The conversion happens entirely in your browser, so your image is never uploaded to a server, and you can convert as many files as you need without creating an account." },
    ],
  },
  {
    slug: "what-is-photo-metadata-and-how-to-remove-it",
    title: "What Is Photo Metadata (EXIF) and How to Remove It Before Sharing",
    description:
      "Photos can carry hidden details like location and camera model. Learn what EXIF metadata is, how to check it, and how to remove it before you share.",
    date: "2026-09-15",
    category: "Privacy",
    toolSlug: "compress-image",
    blocks: [
      { type: "p", text: "When you look at a photo, you see the picture. But the file can also carry a hidden layer of information about how, when and sometimes where it was taken. Most people never notice it, yet it can reveal more than you intended when you share an image online." },
      { type: "h2", text: "What is EXIF metadata?" },
      { type: "p", text: "EXIF is a standard way of storing extra information inside image files, especially JPG photos taken by phones and cameras. It is written automatically when you take the picture. You do not see it on the image itself, but software can read it in an instant." },
      { type: "h2", text: "What kind of information can it contain?" },
      { type: "ul", items: [
        "The date and time the photo was taken.",
        "The make and model of the camera or phone.",
        "Camera settings such as exposure and focal length.",
        "GPS coordinates showing where the picture was taken, if location was switched on.",
        "The software used to edit the file.",
      ] },
      { type: "p", text: "Not every photo has all of these. Screenshots and images saved from websites often carry little or none, while pictures taken directly on a phone with location services enabled are the most likely to include a location." },
      { type: "h2", text: "Why it can matter for privacy" },
      { type: "p", text: "A photo taken at your home and shared with location data intact can reveal where you live. A picture of an item you are selling could show where you keep it. Some websites and social networks remove this data when you upload, but you cannot always be sure how a particular service or a person you send the file to will handle it. Removing it yourself is the safest habit." },
      { type: "h2", text: "How to check a photo's metadata" },
      { type: "p", text: "On Windows, right-click the file, choose Properties and open the Details tab. On a Mac, open the image in Preview, then choose Tools and Show Inspector, and look at the tabs for more details. On phones, the photo info panel in your gallery app often shows the location and camera details. If you can see a location or device name there, that information is stored in the file." },
      { type: "h2", text: "How to remove metadata with ImgSimplify" },
      { type: "p", text: "The tools on this site work by redrawing your image in the browser and saving it again as a new file. Saving a new file this way typically leaves the original metadata behind, so the result usually has no location or camera details. Here is how to use that:" },
      { type: "ol", items: [
        "Open the Compress Image tool and drop in your photo.",
        "Choose JPG or keep Auto, and set the quality to about 90% so the picture stays sharp.",
        "Download the new file.",
        "Check the new file's Properties or Details to confirm the location and camera information are gone.",
      ] },
      { type: "p", text: "It is worth checking the result yourself the first time, because different browsers and image types can behave differently. Do not rely on this alone if you are handling extremely sensitive images." },
      { type: "h2", text: "What removing metadata does not hide" },
      { type: "p", text: "Metadata is only part of the picture. Anyone can still see what is visible in the image itself: street signs, house numbers, number plates, faces, reflections and landmarks in the background. Before sharing, look at the picture carefully and crop or blur anything that gives away more than you want." },
      { type: "h2", text: "Good habits for sharing photos" },
      { type: "ul", items: [
        "Turn off location tagging in your camera app if you do not need it.",
        "Strip metadata from photos you send to strangers, post on forums or use for online listings.",
        "Keep an untouched original for yourself, and share a cleaned copy.",
        "Remember that screenshots of a photo also lose the original metadata.",
      ] },
      { type: "p", text: "Because the processing happens on your own device, your photo is not uploaded to a server while you clean it, which is especially useful when the picture is personal." },
    ],
  },
  {
    slug: "how-to-convert-base64-to-image",
    title: "How to Convert Base64 to an Image (and Fix Broken Data URLs)",
    description:
      "Got a long Base64 string from an API or stylesheet? Learn how to decode it into a picture, and how to fix the most common Base64 image errors.",
    date: "2026-09-10",
    category: "Developers",
    toolSlug: "base64-to-image",
    blocks: [
      { type: "p", text: "Sooner or later most developers meet an image that is not a file at all, but a very long string of letters and numbers. It might come from an API response, a database column, an email template or a stylesheet. Turning that string back into a picture is easy once you know what to look for." },
      { type: "h2", text: "What a Base64 image string looks like" },
      { type: "p", text: "Base64 is a way of writing binary data as plain text. An image in this form usually appears as a data URL. It starts with a short header such as data:image/png;base64, and is followed by the encoded characters. Sometimes you only get the encoded characters without the header, which is called a raw Base64 string." },
      { type: "h2", text: "How to convert Base64 to an image" },
      { type: "ol", items: [
        "Open the Base64 to Image tool.",
        "Paste the full data URL or the raw Base64 string into the text box.",
        "Check the preview panel. If the string is valid, the picture appears.",
        "Click Download image to save it as a file.",
      ] },
      { type: "p", text: "If you paste a string without the data: header, the tool treats it as a PNG. Most browsers still display JPG or WebP data correctly in that case, but the downloaded file will be named as a PNG. Paste the complete data URL when you need the file to have the right extension." },
      { type: "h2", text: "Why the preview says the image is invalid" },
      { type: "p", text: "When the picture does not appear, the string is usually damaged in a small, fixable way. These are the most common causes:" },
      { type: "ul", items: [
        "The string is cut off. Base64 data must be copied completely, and a missing tail will break the image.",
        "Extra characters are included, such as quotation marks, a trailing comma or the word 'base64' typed twice.",
        "Line breaks or spaces were added when the text was wrapped. Remove any whitespace inside the string.",
        "It is not image data at all. Base64 can encode anything, including PDFs and text.",
        "It uses the URL-safe variant of Base64, which swaps the plus sign for a dash and the slash for an underscore.",
      ] },
      { type: "h2", text: "Fixing URL-safe Base64" },
      { type: "p", text: "Some systems, particularly those that put data in web addresses, use a variant where the characters + and / are replaced by - and _. Browsers expect the standard version in a data URL. If your string contains dashes or underscores, replace every dash with a plus sign and every underscore with a slash before pasting it. If the length is not a multiple of four, add equals signs at the end until it is." },
      { type: "h2", text: "Checking the header matches the image" },
      { type: "p", text: "The part after data:image/ tells the browser what kind of picture to expect, for example png, jpeg or webp. If the header says one thing and the data is another, some software will complain. When in doubt, try the raw string without the header and let the browser work out the format." },
      { type: "h2", text: "Very large strings" },
      { type: "p", text: "A Base64 string is roughly a third larger than the original file, and a high-resolution photo can produce millions of characters. Pasting that into a text box can make the page slow, because the browser has to hold everything in memory. If your string is huge, be patient, and if the page freezes, try a smaller image or decode it with a script instead." },
      { type: "h2", text: "Going the other way" },
      { type: "p", text: "If you need to embed a small icon in HTML or CSS, the Image to Base64 tool creates the data URL for you. Remember that Base64 is best for tiny images, since it makes data larger and the browser cannot cache it separately." },
      { type: "h2", text: "A note on privacy" },
      { type: "p", text: "Base64 strings sometimes contain private images, such as user uploads or ID documents. The decoding here happens in your browser, so the text you paste is not sent to a server. Even so, avoid pasting confidential data into any tool on a shared or public computer." },
    ],
  },
  {
    slug: "product-photos-for-online-store",
    title: "How to Prepare Product Photos for Your Online Store",
    description:
      "Better product photos sell more and load faster. Learn the right sizes, backgrounds, formats and file sizes for shop and marketplace listings.",
    date: "2026-09-05",
    category: "E-commerce",
    toolSlug: "resize-image",
    blocks: [
      { type: "p", text: "Shoppers cannot touch what they are buying, so your photos do all the selling. Clear, consistent pictures build trust, while slow, blurry or mismatched ones send people away. You do not need a studio to get this right. A phone, good light and a simple editing routine are enough." },
      { type: "h2", text: "Start with good source photos" },
      { type: "p", text: "Everything begins with the original picture. Shoot in daylight near a window rather than using harsh flash, keep the camera steady, and take several angles: front, back, side and a close-up of details such as texture or labels. Always keep the full-size originals, because you may need them later for a different size or platform." },
      { type: "h2", text: "Keep backgrounds and framing consistent" },
      { type: "p", text: "A store looks professional when its pictures share the same look. Use the same background colour, similar lighting and the same distance from the product across your whole catalogue. A plain white or light grey background keeps attention on the item. If you have product images with transparent backgrounds, converting them to JPG fills the transparent area with white, which suits most shop pages." },
      { type: "h2", text: "Use a consistent aspect ratio" },
      { type: "p", text: "Product grids look messy when some pictures are tall and some are wide. Many shops use square 1:1 images because they line up neatly in rows. Others prefer 4:3 or 3:4. Pick one shape and stick to it. The Image Cropper can crop your photos to a chosen ratio, so every product fits the same space." },
      { type: "h2", text: "Choose a sensible size in pixels" },
      { type: "p", text: "Your photos need to be large enough to look sharp and, on many stores, large enough to support a zoom feature. Requirements differ between platforms, so check the guidance for your own shop or marketplace. As a general rule, an image around 1000 to 2000 pixels on the longest side works well for a main product photo, while smaller versions are used for thumbnails. Do not enlarge a small photo to reach a size, because it will only look blurry." },
      { type: "h2", text: "Keep file sizes small" },
      { type: "p", text: "A shop page can show dozens of pictures at once, so heavy files add up fast. Large images slow the page, and slow pages lose customers, especially on mobile. Resize each photo, then compress it. For most product photos, a quality between 75% and 85% looks clean while cutting the file size dramatically. Aim to keep each image well under a few hundred kilobytes when you can." },
      { type: "h2", text: "Pick the right format" },
      { type: "ul", items: [
        "JPG: the safe default for product photographs and accepted almost everywhere.",
        "WebP: smaller files at similar quality, good for your own website if your platform supports it.",
        "PNG: useful for logos, badges and graphics with sharp edges or transparency, but large for photos.",
      ] },
      { type: "h2", text: "A simple editing routine" },
      { type: "ol", items: [
        "Crop each photo to your chosen aspect ratio.",
        "Resize it to your target size using the Resize Image tool, keeping the aspect ratio locked.",
        "Compress it around 80% quality and check the preview for any visible artifacts.",
        "Convert to WebP if your shop supports it, or keep the JPG.",
        "Rename the file with a clear description, such as blue-cotton-tshirt-front.jpg.",
      ] },
      { type: "h2", text: "Do not forget alt text and file names" },
      { type: "p", text: "Descriptive file names and alt text help search engines understand your products, and they make your store easier to use with a screen reader. Describe the item plainly, including colour and type, and avoid repeating the same phrase on every image." },
      { type: "h2", text: "Protect your privacy" },
      { type: "p", text: "Photos taken on a phone can carry location data. If you photograph items at home, that information could reveal where you live. Re-saving your images through ImgSimplify typically removes it, and because everything runs in your browser, your pictures are not uploaded to a server while you work." },
    ],
  },
  {
    slug: "compress-image-to-100kb",
    title: "How to Compress an Image to 100KB (or 50KB) Without Ruining It",
    description:
      "Need a photo under 100KB or 50KB for a form or upload? Learn the size and quality tricks that work, and how to do it free in your browser.",
    date: "2026-08-28",
    category: "Compression",
    toolSlug: "compress-image-to-100kb",
    blocks: [
      { type: "p", text: "Job portals, government forms, exam registrations and online stores often refuse an upload because the photo is too big. The message is usually something like 'file must be under 100KB' or 'maximum size 50KB'. A modern phone photo is several megabytes, so you need to shrink it a lot. The good news is that with the right order of steps, you can hit these limits and still end up with a picture that looks perfectly fine." },
      { type: "h2", text: "Why upload forms ask for such small files" },
      { type: "p", text: "Websites that receive thousands of uploads every day have to store every file and load it again whenever someone reviews an application. Small limits keep storage costs down and pages fast. The limit is not a judgement on your photo. It simply means you need to remove data the form does not need." },
      { type: "h2", text: "What decides the size of an image file" },
      { type: "p", text: "Four things control how many kilobytes a picture takes up, and knowing them tells you which lever to pull first." },
      { type: "ul", items: [
        "Pixel dimensions: a photo that is 4000 pixels wide holds many times more data than one that is 1000 pixels wide.",
        "Quality setting: lossy formats such as JPG and WebP throw away fine detail. A lower quality number means a smaller file.",
        "File format: JPG and WebP are usually much smaller than PNG for photographs.",
        "Image content: a plain background compresses far better than a busy scene full of texture and noise.",
      ] },
      { type: "p", text: "Of these, pixel dimensions usually make the biggest difference, which is why the best method is to resize first and compress second." },
      { type: "h2", text: "How to get an image under 100KB" },
      { type: "ol", items: [
        "Open the Resize Image tool and drop in your photo. Note the original width and height shown under the preview.",
        "Reduce the width to about 800 to 1200 pixels with the aspect ratio lock switched on, then download the resized file. For a passport-style photo or a small profile picture, 600 pixels is often enough.",
        "Open the Compress Image tool and upload the resized file. Set the output format to JPG.",
        "Start with the quality slider around 80%. Look at the new file size shown next to the preview.",
        "If the file is still above 100KB, lower the quality by 5 to 10 points at a time and check again. If the picture starts to look blocky, go back up a step and reduce the pixel dimensions further instead.",
        "Click Download and upload the compressed file to the form.",
      ] },
      { type: "p", text: "ImgSimplify does not have a box where you type a target size such as 100KB. You reach the number by adjusting the dimensions and the quality slider while watching the size update. It usually takes only two or three tries." },
      { type: "h2", text: "How to get an image under 50KB" },
      { type: "p", text: "The same method works, but you need to be a little more aggressive. Reduce the width to somewhere between 400 and 700 pixels, choose JPG, and try a quality between 60% and 75%. Small images can tolerate lower quality because the file has fewer pixels to begin with, and most forms only show the photo as a small thumbnail anyway. If the image has a plain background, such as a passport photo against a white wall, it will compress much better than a busy outdoor shot." },
      { type: "h2", text: "A rough idea of what to expect" },
      { type: "p", text: "Sizes depend heavily on what is in the picture, so treat these as ballpark figures. A photo around 1200 pixels wide saved as a JPG at 80% quality often lands somewhere between 100KB and 250KB. Cutting the width to 800 pixels typically brings it well under 100KB. Screenshots and graphics with sharp text behave differently, and they can be larger as JPG than you expect because compression struggles with hard edges." },
      { type: "h2", text: "Which format should you choose" },
      { type: "p", text: "For photographs, JPG is the safest choice because every upload form accepts it. WebP can be even smaller, but some forms and older software reject it, so only use it when you know it is allowed. Avoid PNG for photos when a size limit applies, because PNG keeps every pixel and is often several times larger. If a form demands PNG, resize the image as small as is acceptable, since compression settings have little effect on PNG files." },
      { type: "h2", text: "Common mistakes to avoid" },
      { type: "ul", items: [
        "Compressing an already tiny image again and again. Each pass loses a little more detail, so always start from your original file.",
        "Stretching a small image to make it 'bigger' before uploading. That adds pixels but no detail, and can make the file larger.",
        "Setting quality extremely low straight away. It is better to resize first and keep quality reasonable.",
        "Renaming a file to .jpg without converting it. The form may still detect the true format and reject it.",
      ] },
      { type: "h2", text: "Keep your original and stay private" },
      { type: "p", text: "Always keep a copy of the original photo, because you may need the full-size version later. Passport photos, ID scans and certificates are also sensitive, which is one more reason to use a browser-based tool. ImgSimplify processes the image on your own device, so the file is not sent to a server to be resized or compressed. Once you have your small file, upload it to the form and you are done." },
    ],
  },
  {
    slug: "what-is-avif-vs-jpg-vs-webp",
    title: "What Is AVIF? AVIF vs JPG vs WebP Explained",
    description:
      "AVIF makes images much smaller, but not every app opens it. Learn what AVIF is, how it compares with JPG and WebP, and how to convert AVIF to JPG.",
    date: "2026-08-21",
    category: "Formats",
    toolSlug: "avif-to-jpg",
    blocks: [
      { type: "p", text: "You right-click an image on a website, choose save, and end up with a file that ends in .avif. Then your photo editor, email client or upload form refuses to open it. AVIF is one of the newest image formats on the web, and it is designed to make pictures much smaller. That is great for websites, but it can be confusing when you just want an ordinary image file." },
      { type: "h2", text: "What is AVIF?" },
      { type: "p", text: "AVIF stands for AV1 Image File Format. It is based on the AV1 video codec, which was developed to compress video efficiently. The image version applies the same ideas to still pictures. AVIF supports transparency, a wide range of colours, high dynamic range and even animation, so in features it can do almost everything JPG, PNG and WebP can do combined." },
      { type: "h2", text: "Why AVIF files are smaller" },
      { type: "p", text: "Like JPG, AVIF is a lossy format, which means it discards detail that people are unlikely to notice. Its compression methods are more advanced than JPG's, so at similar visual quality an AVIF file is often noticeably smaller than the equivalent JPG, and usually smaller than WebP too. How much smaller depends on the image, so treat any single percentage with caution. Smooth photos and gradients tend to benefit most." },
      { type: "h2", text: "AVIF vs JPG vs WebP at a glance" },
      { type: "ul", items: [
        "JPG: works everywhere, no transparency, larger files. Best for maximum compatibility.",
        "WebP: smaller than JPG, supports transparency, and is accepted by all current major browsers. A good all-round web format.",
        "AVIF: often the smallest files with excellent quality and transparency support, but newer, so some software and services do not accept it yet.",
      ] },
      { type: "h2", text: "Browser and app support" },
      { type: "p", text: "Current versions of Chrome, Edge, Firefox and Safari can display AVIF images. Safari was the last of the big four to add support, arriving around version 16, so people on older iPhones, iPads and Macs may not see AVIF images at all. Support outside browsers is patchier. Some photo editors, email programs, document tools, print services and upload forms were built before AVIF existed and simply do not recognise the format." },
      { type: "h2", text: "Why your AVIF file will not open" },
      { type: "p", text: "There are two common reasons. The first is that the program you are using does not support AVIF, which is the most likely cause for older software. The second is that a website served you AVIF because your browser said it could handle it, and you then tried to use the saved file somewhere that cannot. In both cases the fix is the same: convert the file to a format that everything understands, and JPG is the safest choice." },
      { type: "h2", text: "How to convert AVIF to JPG" },
      { type: "ol", items: [
        "Open the AVIF to JPG tool.",
        "Drop in your .avif file or click to choose it. Your browser needs to be able to open AVIF for the file to load, which current versions of the major browsers can.",
        "Adjust the quality slider if you want a smaller or sharper result. Around 85% to 90% is a good starting point.",
        "Click Download to save your JPG.",
      ] },
      { type: "p", text: "Keep in mind that JPG does not support transparency, so any transparent area in your AVIF becomes white. The JPG will also usually be larger than the AVIF, because AVIF compresses more efficiently. If you need to keep transparency, a PNG is a better target. ImgSimplify does not currently offer AVIF to PNG, so for a transparent AVIF you may need an image editor." },
      { type: "h2", text: "Should you use AVIF on your own website?" },
      { type: "p", text: "If you run a website, AVIF can noticeably reduce image weight, which helps pages load faster. The safe approach is to offer AVIF first and fall back to a widely supported format. In HTML, the picture element lets you list an AVIF source followed by a WebP or JPG fallback, and each browser picks the first format it understands. Many website frameworks and image services can generate these versions automatically. If you would rather keep things simple, WebP already gives a large saving over JPG with very broad support." },
      { type: "h2", text: "Which format should you pick?" },
      { type: "p", text: "For sharing photos with other people or uploading to forms, use JPG. For a modern website where speed matters, use WebP or AVIF with a fallback. For logos and graphics that need sharp edges and transparency, use PNG or WebP. When an AVIF file causes trouble, converting it takes a few seconds, and because ImgSimplify works inside your browser, your picture is never uploaded to a server while you do it." },
    ],
  },
  {
    slug: "resize-image-without-losing-quality",
    title: "How to Resize an Image Without Losing Quality",
    description:
      "Learn how to resize photos to exact pixel sizes without blur or stretching. Simple rules, recommended sizes and a free browser-based resizer.",
    date: "2026-08-14",
    category: "Resizing",
    toolSlug: "resize-image",
    blocks: [
      { type: "p", text: "Resizing sounds simple, yet it is easy to end up with a blurry, stretched or oddly cropped picture. Whether you are preparing a profile photo, a blog header or a product image, a few basic rules will keep your pictures sharp. The most important one is to understand what resizing actually does to an image." },
      { type: "h2", text: "Resizing is not the same as compressing" },
      { type: "p", text: "Resizing changes the number of pixels in the picture, for example from 4000 by 3000 to 1200 by 900. Compressing keeps the pixel count but stores the data more tightly, usually by discarding fine detail. Both reduce file size, but they work differently. Resizing is often the more powerful of the two, because a picture with fewer pixels simply contains less information. For the smallest files, resize first and then compress." },
      { type: "h2", text: "Making an image smaller is safe, making it bigger is not" },
      { type: "p", text: "When you shrink an image, the software combines groups of pixels into fewer ones, and the result stays crisp. When you enlarge an image, it has to invent pixels that were never captured, and the picture looks soft or blocky. No tool can add real detail that was not in the original. So whenever possible, start from the largest original you have and scale down, rather than scaling a small image up." },
      { type: "h2", text: "Keep the aspect ratio locked" },
      { type: "p", text: "The aspect ratio is the relationship between width and height. If you change only one of them without adjusting the other, the picture looks squashed or stretched, and faces and circles stop looking right. The Resize Image tool has a Lock aspect ratio option that is on by default. With it on, typing a new width automatically works out the matching height. Turn it off only when you deliberately want different proportions, and remember that this will distort the picture. If you need a specific shape such as a square, use the Image Cropper first and resize afterwards." },
      { type: "h2", text: "Choosing the right size" },
      { type: "p", text: "There is no single perfect size, because it depends on where the image will appear. These are practical starting points:" },
      { type: "ul", items: [
        "Full-width website banner or hero image: around 1600 to 2000 pixels wide.",
        "Images inside a blog post or article: around 800 to 1200 pixels wide.",
        "Thumbnails and product grid images: around 300 to 600 pixels wide.",
        "Profile pictures and avatars: around 400 to 800 pixels on the longest side.",
        "Email attachments and quick sharing: around 1200 to 1600 pixels is plenty for viewing on screens.",
      ] },
      { type: "p", text: "Screens with very sharp displays can show more detail, so if an image appears at a certain width on the page, using an image up to about twice that width keeps it crisp on those screens. Going far beyond that only makes the file heavier without any visible benefit." },
      { type: "h2", text: "How to resize an image with ImgSimplify" },
      { type: "ol", items: [
        "Open the Resize Image tool and drop in your JPG, PNG or WebP file.",
        "Check the original dimensions displayed under the preview.",
        "Type the new width or the new height in pixels. Keep the aspect ratio lock on so the other value updates for you.",
        "Look at the preview and the new dimensions and file size in the summary.",
        "Click Download to save the resized image.",
      ] },
      { type: "h2", text: "Compress after you resize" },
      { type: "p", text: "Once your picture has the right dimensions, run it through the Compress Image tool. A resized photo at 80% quality is usually far smaller than the original and still looks good on screen. Doing it in this order gives you the smallest file that still looks sharp, and it avoids compressing a huge image that you were going to shrink anyway." },
      { type: "h2", text: "Do not resize the same file again and again" },
      { type: "p", text: "Every time a JPG is opened, changed and saved again, it is re-encoded and loses a tiny amount of quality. Doing that many times adds up. Always keep your original file untouched, and create each new size from that original rather than from a copy you have already resized. That way every version is as good as it can be." },
      { type: "h2", text: "Common resizing mistakes" },
      { type: "ul", items: [
        "Enlarging a small image to fill a big space and then wondering why it is blurry.",
        "Turning off the aspect ratio lock by accident and stretching the picture.",
        "Resizing a screenshot with small text so much that the text becomes unreadable.",
        "Uploading a huge original to a website and letting the page shrink it, which wastes bandwidth and slows loading.",
      ] },
      { type: "p", text: "Resizing in your browser also keeps your pictures private. ImgSimplify does the work on your own device, so your photo is not uploaded to a server, and you can resize as many images as you like without an account." },
    ],
  },
  {
    slug: "why-website-images-are-slow",
    title: "Why Your Website Images Are Slow (and How to Fix Them)",
    description:
      "Heavy images are one of the top reasons pages load slowly. Learn how to find them and fix them with resizing, WebP, compression and lazy loading.",
    date: "2026-08-09",
    category: "Performance",
    toolSlug: "jpg-to-webp",
    blocks: [
      { type: "p", text: "If your website feels slow, images are a very likely cause. A single unoptimised photo can weigh more than the rest of a page put together. Visitors on mobile connections leave slow pages quickly, and speed also affects how your site performs in search. The encouraging part is that image problems are among the easiest speed problems to fix." },
      { type: "h2", text: "Why images matter so much" },
      { type: "p", text: "On most pages the largest visible element is an image, such as a banner or a product photo. Google's Core Web Vitals include a measure called Largest Contentful Paint, which tracks how long that main element takes to appear, and Google suggests aiming for 2.5 seconds or less. If your biggest image is several megabytes, it is almost impossible to reach that on a phone." },
      { type: "h2", text: "Step one: find the heavy images" },
      { type: "p", text: "You do not have to guess. Open your page in Chrome, press F12 to open the developer tools, go to the Network tab and reload the page. Filter by Img and sort by size, and you will see exactly which files are heaviest. You can also run your page through Google's PageSpeed Insights, which lists images that are too large or in an old format and estimates how much you would save." },
      { type: "h2", text: "Fix 1: resize images to the size you actually display" },
      { type: "p", text: "The most common mistake is uploading a 4000-pixel photo straight from a camera and displaying it in a space that is 800 pixels wide. The browser downloads every pixel and then throws most of them away. Resize each image to roughly the largest size it will appear, or up to about twice that for sharp screens. The Resize Image tool does this in a few clicks." },
      { type: "h2", text: "Fix 2: use a modern format like WebP" },
      { type: "p", text: "WebP files are typically 25% to 35% smaller than JPG at similar quality, and they support transparency like PNG. All current major browsers can display WebP. Converting your JPG and PNG images with the JPG to WebP or PNG to WebP tool is a quick way to cut page weight without visibly changing your pictures." },
      { type: "h2", text: "Fix 3: compress before you upload" },
      { type: "p", text: "Even after resizing, most photos can be compressed further. A quality of around 75% to 85% usually looks the same to the eye and saves a large amount of data. Preview the result and lower the quality until you just start to see a difference, then step back slightly." },
      { type: "h2", text: "Fix 4: lazy load images below the fold" },
      { type: "p", text: "Images further down the page do not need to load until the visitor scrolls near them. Adding the attribute loading='lazy' to an image tag tells the browser to wait, which makes the first screen appear sooner and saves data for people who never scroll that far. Do not lazy load the main image at the top of the page, because that one should load as early as possible." },
      { type: "h2", text: "Fix 5: set width and height on every image" },
      { type: "p", text: "When an image has no stated size, the browser does not know how much space to reserve, so the text jumps down when the picture finally appears. This layout shift is annoying and it counts against you in Core Web Vitals. Adding width and height attributes, or a fixed aspect ratio in your CSS, lets the browser reserve the space in advance." },
      { type: "h2", text: "Fix 6: serve different sizes to different screens" },
      { type: "p", text: "A phone does not need the same large image as a wide desktop monitor. The srcset attribute lets you offer several sizes of the same image, and the browser picks the most suitable one. If you use a framework such as Next.js, its image component can create these versions and convert them to modern formats for you." },
      { type: "h2", text: "Fix 7: use caching and a CDN" },
      { type: "p", text: "Once your images are small, make sure returning visitors do not download them again. Good hosting sets caching headers so the browser keeps a copy, and a content delivery network serves files from a location close to each visitor. Most modern hosting platforms include both." },
      { type: "h2", text: "A simple checklist before you upload any image" },
      { type: "ol", items: [
        "Resize it to the size it will actually be displayed.",
        "Convert photos to WebP, or keep JPG if you need maximum compatibility.",
        "Compress it around 75% to 85% quality and check the preview.",
        "Give it a clear file name and add descriptive alt text on the page.",
        "Add width and height, and lazy load it if it is below the fold.",
      ] },
      { type: "p", text: "All of the ImgSimplify tools run inside your browser, so you can prepare your website images without uploading them anywhere. Do this consistently for every new image and your pages will load faster, your visitors will stay longer, and your site will be easier to keep fast as it grows." },
    ],
  },
  {
    slug: "image-aspect-ratios-explained",
    title: "Image Aspect Ratios Explained: 1:1, 4:3, 16:9 and 9:16",
    description:
      "Learn what aspect ratios like 1:1, 4:3, 16:9 and 9:16 mean, where to use each one, and how to crop an image to fit without stretching it.",
    date: "2026-08-01",
    category: "Cropping",
    toolSlug: "crop-image",
    blocks: [
      { type: "p", text: "You upload a photo and it gets cut off, or it appears with ugly bars on the sides. Nine times out of ten the cause is the aspect ratio. Understanding it takes only a few minutes, and it lets you prepare pictures that fit profile spaces, thumbnails, banners and stories exactly the way you want." },
      { type: "h2", text: "What is an aspect ratio?" },
      { type: "p", text: "The aspect ratio describes the shape of an image as the relationship between its width and its height, written as two numbers separated by a colon. A ratio of 1:1 means the width and height are equal, so the picture is a square. A ratio of 16:9 means that for every 16 units of width there are 9 units of height, which gives a wide rectangle. The ratio does not say how many pixels the image has, only its shape. A 1000 by 1000 picture and a 500 by 500 picture are both 1:1." },
      { type: "h2", text: "The most common aspect ratios and where they fit" },
      { type: "ul", items: [
        "1:1 (square): profile pictures, avatars, square social posts and many product listings.",
        "4:3: the classic photo and screen shape, used by many compact cameras, tablets and presentations.",
        "3:4: the same shape turned upright, common for portrait photos and some product images.",
        "16:9 (wide): video, YouTube thumbnails, website banners and widescreen displays.",
        "9:16 (tall): vertical video, phone wallpapers and full-screen stories and short videos.",
      ] },
      { type: "p", text: "Platforms change their recommended sizes from time to time, so always check the current guidance for the place you are uploading to. The ratios above are a reliable starting point, and knowing them lets you adapt quickly when a platform updates." },
      { type: "h2", text: "Cropping, resizing and stretching are different things" },
      { type: "p", text: "To change the shape of a picture you have three options, and only two of them look good. Cropping cuts away part of the image so that what remains has the ratio you want. Resizing keeps the shape and changes the number of pixels. Stretching forces the width and height to new values without regard for the original proportions, which distorts the picture. To get a new shape without distortion, crop first, then resize if you also need a particular pixel size." },
      { type: "h2", text: "How to crop an image to a set aspect ratio" },
      { type: "ol", items: [
        "Open the Image Cropper and drop in your JPG, PNG or WebP file.",
        "Choose the ratio you need: 1:1, 4:3, 3:4, 16:9 or 9:16.",
        "Check the preview and the new dimensions shown in the summary.",
        "Click Download to save the cropped image.",
      ] },
      { type: "p", text: "The ImgSimplify cropper takes the largest possible area of the chosen ratio from the centre of your picture. It does not have a draggable box for choosing a different part of the image, so it works best when your subject is near the middle. If you need to choose exactly which area to keep, crop in an image editor first and then use the tools here to resize and compress." },
      { type: "h2", text: "Composition tips before you crop" },
      { type: "p", text: "A crop removes parts of the picture, so think about what you can afford to lose. When you are taking a photo that will later become a square or a tall story, keep the important subject near the centre and leave some empty space around it. Faces work best when they are not too close to the edges. If you are cropping from a wide photo to a tall one, expect to lose a lot from the left and right sides, so check that nothing important disappears." },
      { type: "h2", text: "Match the ratio to the job" },
      { type: "ul", items: [
        "Profile picture: use 1:1 so the image is not cut off when it is shown inside a circle or square.",
        "Video thumbnail or website banner: use 16:9 so it fills the space without bars.",
        "Vertical story or short video cover: use 9:16.",
        "Classic photo prints and presentations: 4:3 or 3:4 depending on orientation.",
      ] },
      { type: "h2", text: "Common cropping mistakes" },
      { type: "ul", items: [
        "Cropping a low-resolution image so tightly that the result is tiny and looks blurry when enlarged.",
        "Cropping first and then stretching the result to fit a space, which brings the distortion back.",
        "Forgetting to keep the original file, so you cannot try a different ratio later.",
        "Assuming every platform crops from the centre. Some crop from the top, so keep faces away from the very top edge.",
      ] },
      { type: "p", text: "Cropping in your browser keeps your photos private, because ImgSimplify does the work on your own device and never uploads the file. Keep your original, crop copies for each purpose, and your pictures will fit wherever you post them." },
    ],
  },
  {
    slug: "jpg-vs-png-vs-webp",
    title: "JPG vs PNG vs WebP: Which Image Format Should You Use?",
    description:
      "Compare JPG, PNG and WebP by quality, file size, transparency and browser support, and learn which image format is best for photos, logos and websites.",
    date: "2026-07-25",
    category: "Formats",
    toolSlug: "jpg-to-webp",
    blocks: [
      { type: "p", text: "Picking the wrong image format can make a website slower or a logo look blurry. JPG, PNG and WebP are the three formats you will meet most often online, and each one is good at something different." },
      { type: "h2", text: "JPG: best for photographs" },
      { type: "p", text: "JPG (also written JPEG) uses lossy compression, which throws away detail the human eye barely notices. That makes it excellent for photos, where it can shrink a file dramatically. The trade-offs are that JPG does not support transparency, and saving the same image again and again gradually reduces quality." },
      { type: "h2", text: "PNG: best for logos, screenshots and transparency" },
      { type: "p", text: "PNG is lossless, so every pixel is preserved exactly. It supports transparent backgrounds and keeps text and sharp edges crisp, which is why it is the usual choice for logos, icons and screenshots. The downside is size: a photo saved as PNG is often several times larger than the same photo saved as JPG." },
      { type: "h2", text: "WebP: the modern all-rounder" },
      { type: "p", text: "WebP can be lossy or lossless and it supports transparency, so it can replace both JPG and PNG in most cases. Google's own tests found lossy WebP files roughly 25–34% smaller than comparable JPGs. All current major browsers support it." },
      { type: "h2", text: "Quick comparison" },
      { type: "ul", items: [
        "Photos: WebP or JPG",
        "Logos, icons and screenshots: PNG or WebP",
        "Transparent backgrounds: PNG or WebP (JPG cannot do transparency)",
        "Maximum compatibility with older software: JPG",
      ] },
      { type: "h2", text: "Which should you choose?" },
      { type: "p", text: "For a website, WebP is usually the best default because it gives smaller files at similar quality. Keep JPG when you need to share images with older apps, and PNG when you need exact pixels for editing. You can switch between all three at any time with the free converters on ImgSimplify, and everything happens in your browser, so your images are never uploaded." },
    ],
  },
  {
    slug: "how-to-compress-images-without-losing-quality",
    title: "How to Compress Images Without Losing Quality",
    description:
      "Learn how to compress JPG, PNG and WebP images online for free. Simple steps to reduce file size while keeping photos sharp, without uploading anything.",
    date: "2026-07-17",
    category: "Compression",
    toolSlug: "compress-image",
    blocks: [
      { type: "p", text: "Large images are one of the most common reasons a web page loads slowly. The good news is that most photos can be made much smaller with no visible difference, as long as you compress them the right way." },
      { type: "h2", text: "Understand lossy and lossless compression" },
      { type: "p", text: "Lossy compression (JPG and lossy WebP) removes detail that is hard to notice, and it gives the biggest savings. Lossless compression (PNG) keeps every pixel but saves far less space. For photos, lossy is almost always the right choice." },
      { type: "h2", text: "Pick a quality between 70% and 85%" },
      { type: "p", text: "Quality settings are not linear. Dropping from 100% to about 80% usually cuts the file size dramatically while looking the same to the eye. Below roughly 60% you start to see blocky artifacts, especially around edges and in smooth gradients." },
      { type: "h2", text: "Resize before you compress" },
      { type: "p", text: "A photo straight from a phone can be 4000 pixels wide, while a website often displays it at 800 or 1200. Reducing the pixel dimensions first removes far more data than compression alone. Resize to the largest size you will actually display, then compress." },
      { type: "h2", text: "How to compress an image with ImgSimplify" },
      { type: "ol", items: [
        "Open the Compress Image tool and drop in your JPG, PNG or WebP file.",
        "Move the quality slider until the preview still looks good, around 75–85% for most photos.",
        "Compare the original and new file sizes shown next to the preview.",
        "Click Download to save the smaller image.",
      ] },
      { type: "h2", text: "Keep your images private" },
      { type: "p", text: "Because ImgSimplify compresses images inside your browser, your files are never uploaded. Re-encoding an image in the browser also typically removes hidden metadata such as camera details and GPS location, which is a small privacy bonus when you share photos online." },
    ],
  },
  {
    slug: "convert-webp-to-jpg",
    title: "How to Convert WebP to JPG (and When You Should)",
    description:
      "Need a JPG instead of WebP? Learn why WebP images fail to open in some apps, when to convert WebP to JPG, and how to do it free in your browser.",
    date: "2026-07-11",
    category: "Converting",
    toolSlug: "webp-to-jpg",
    blocks: [
      { type: "p", text: "You save an image from a website and discover it is a .webp file that your photo editor, email client or upload form refuses to open. WebP is great for the web, but not every program supports it yet, so converting WebP to JPG is a common fix." },
      { type: "h2", text: "Why WebP images do not open everywhere" },
      { type: "p", text: "WebP was designed for fast websites, and modern browsers all handle it. Older desktop software, some print services and many document and upload tools were built before WebP became common, so they only accept JPG or PNG." },
      { type: "h2", text: "When you should convert WebP to JPG" },
      { type: "ul", items: [
        "An app or website rejects your WebP upload",
        "You need to share a photo with someone using older software",
        "You want a format that every device understands",
      ] },
      { type: "h2", text: "What you lose when converting" },
      { type: "p", text: "JPG does not support transparency, so any transparent area becomes a solid color (ImgSimplify fills it with white). Converting also re-compresses the image, so choose a high quality setting to keep it looking sharp, and keep the original WebP if you may need it later. Expect the JPG to be somewhat larger than the WebP." },
      { type: "h2", text: "How to convert WebP to JPG online" },
      { type: "ol", items: [
        "Open the WebP to JPG tool.",
        "Drop in your .webp file or click to choose it.",
        "Adjust the quality slider if you want a smaller or sharper result.",
        "Click Download to save your JPG.",
      ] },
      { type: "p", text: "The conversion runs entirely in your browser, so your image is never uploaded to a server." },
    ],
  },
  {
    slug: "image-to-base64-when-to-use",
    title: "Image to Base64: What It Is and When to Use It",
    description:
      "Learn what Base64 image encoding is, how much it increases file size, and when to embed images as data URLs in HTML, CSS or JSON.",
    date: "2026-07-06",
    category: "Developers",
    toolSlug: "image-to-base64",
    blocks: [
      { type: "p", text: "Base64 turns binary data, such as an image, into plain text. That text can be pasted straight into HTML, CSS or JSON, which is handy when you want to include an image without hosting a separate file." },
      { type: "h2", text: "What is a Base64 image?" },
      { type: "p", text: "A Base64 image is usually written as a data URL that starts with something like data:image/png;base64, followed by a long string of characters. Browsers can display it exactly like a normal image file." },
      { type: "h2", text: "When Base64 images make sense" },
      { type: "ul", items: [
        "Tiny icons or logos embedded directly in CSS or HTML",
        "Small images inside JSON payloads or API requests",
        "Single-file demos, prototypes and code snippets",
      ] },
      { type: "h2", text: "When to avoid it" },
      { type: "p", text: "Base64 makes data about 33% larger than the original file, and an embedded image cannot be cached separately by the browser. For photos or anything larger than a few kilobytes, a normal image file (ideally WebP) served from your site or a CDN is faster." },
      { type: "h2", text: "How to convert an image to Base64" },
      { type: "ol", items: [
        "Open the Image to Base64 tool and drop in your file.",
        "Copy the generated Base64 data URL.",
        "Paste it into an HTML src attribute, a CSS url() or your JSON.",
      ] },
      { type: "p", text: "Need to go the other way? The Base64 to Image tool decodes a string back into a downloadable image file. Both tools run locally in your browser." },
    ],
  },
];

// New articles first, short articles get their extra sections, then newest first.
export const POSTS: Post[] = [...NEW_POSTS, ...BASE_POSTS]
  .map((p) => {
    const extra = POST_EXPANSIONS[p.slug];
    return extra ? { ...p, blocks: [...p.blocks, ...extra.blocks], updated: extra.updated } : p;
  })
  .sort((a, b) => b.date.localeCompare(a.date));

export const getPost = (slug: string) => POSTS.find((p) => p.slug === slug);

/** Same category first, then same tool, then newest. Never includes the post itself. */
export const getRelatedPosts = (post: Post, limit = 3): Post[] => {
  const score = (p: Post) =>
    (p.category === post.category ? 2 : 0) + (p.toolSlug === post.toolSlug ? 1 : 0);
  return POSTS.map((p, index) => ({ p, index, s: score(p) }))
    .filter(({ p }) => p.slug !== post.slug)
    .sort((a, b) => b.s - a.s || a.index - b.index)
    .slice(0, limit)
    .map(({ p }) => p);
};

const countWords = (p: Post) =>
  p.blocks
    .map((b) => ("text" in b ? b.text : b.items.join(" ")))
    .join(" ")
    .split(/\s+/).length;

export const readMinutes = (p: Post) => Math.max(1, Math.ceil(countWords(p) / 200));

export const formatDate = (iso: string) =>
  new Date(iso).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
    timeZone: "UTC",
  });